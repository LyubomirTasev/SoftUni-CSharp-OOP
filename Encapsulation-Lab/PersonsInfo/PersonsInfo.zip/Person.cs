﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PersonsInfo
{
    public class Person
    {
        // Name must be at least 3 symbols
        //Age must not be zero or negative
        //Salary can' t be less than 460 (decimal)

        //Print proper messages to the user:

        //Age cannot be zero or a negative integer!
        //First name cannot contain fewer than 3 symbols!
        //Last name cannot contain fewer than 3 symbols!
        //Salary cannot be less than 460 leva!

        private string firstName;
        private string lastName;
        private int age;
        private decimal salary;

        public string FirstName
        {
            get
            {
                return this.firstName;
            }
            private set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("First name cannot contain fewer than 3 symbols!");
                }
                firstName = value;
            }
        }

        public string LastName
        {
            get
            {
                return this.lastName;
            }
            private set
            {
                if (value.Length < 3)
                {
                    throw new ArgumentException("Last name cannot contain fewer than 3 symbols!");
                }
                lastName = value;
            }
        }

        public int Age
        {
            get
            {
                return this.age;
            }
            private set
            {
                if (value < 1)
                {
                    throw new ArgumentException("Age cannot be zero or a negative integer!");
                }
                age = value;
            }
        }

        public decimal Salary
        {
            get
            {
                return this.salary;
            }
            private set
            {
                if (value < 460)
                {
                    throw new ArgumentException("Salary cannot be less than 460 leva!");
                }
                salary = value;
            }
        }

        public Person(string firstName, string lastName, int age)
        {
            this.FirstName = firstName;
            this.LastName = lastName;
            this.Age = age;
        }

        public Person(string firstName, string lastName, int age, decimal salary)
            : this(firstName, lastName, age)
        {
            Salary = salary;
        }

        public void IncreaseSalary(decimal percentage)
        {
            if (this.age > 30)
            {
                salary += salary * percentage / 100;
            }
            else
            {
                salary += salary * percentage / 200;
            }

            //decimal increase = percentage;

            //if (Age < 30)
            //{
            //    increase = percentage / 2;
            //}

            //Salary += Salary * increase / 2;
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} receives {Salary:f2} leva.";
        }
    }
}
