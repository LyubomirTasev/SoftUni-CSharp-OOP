﻿using System;
using System.Collections.Generic;
using System.Text;

namespace MillitaryElite
{
    public enum Corps
    {
        Airforces,
        Marines
    }
}
